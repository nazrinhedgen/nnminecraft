This resource pack, and it's assets were made by TwistedDreams#0001
I want to thank you for purchasing my product, if you have any suggestions, commission requests or issues then please do not hesitate to reach out to me.


Included in this zip file are:
 - A resource pack containing x7 unique custom tool textures.

To give yourself the items, copy and paste the following commands (If you use essentials you may need to change
/give to /minecraft:give)

/give @p minecraft:netherite_sword{CustomModelData:1}
/give @p minecraft:netherite_pickaxe{CustomModelData:1}
/give @p minecraft:netherite_axe{CustomModelData:1}
/give @p minecraft:netherite_shovel{CustomModelData:1}
/give @p minecraft:netherite_hoe{CustomModelData:1}
/give @p minecraft:bow{CustomModelData:1}
/give @p minecraft:crossbow{CustomModelData:1}